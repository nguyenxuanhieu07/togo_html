<?php return array('dependencies' => array(), 'version' => 'aa90c0c82912bd3a64ea');
